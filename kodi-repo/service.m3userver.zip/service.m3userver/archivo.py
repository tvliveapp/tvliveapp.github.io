import xbmc
import xbmcvfs
import os

def writeA_mismo_directorio(filename, text):
    try:
        # 1. Extrae de forma nativa el directorio donde reside este script actual
        directorio_actual = os.path.dirname(os.path.abspath(__file__))
        
        # 2. Une el directorio con el nombre de tu archivo externo
        nombre_limpio = filename.lstrip('/')
        path_completo = os.path.join(directorio_actual, nombre_limpio)
        
        # 3. Al ser una ruta local del sistema extraída directamente, usamos open() estándar
        with open(path_completo, 'w', encoding='utf-8') as f:
            f.write(text)
            
        xbmc.log(f"[MiLibreria] Archivo creado en el directorio del script: {path_completo}", xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log(f"[MiLibreria] Error en directorio local: {str(e)}", xbmc.LOGERROR)
        return False

# Solo le pasas el argumento con el nombre:
writeA_mismo_directorio("/nuevoMqtt.txt", "Tus datos Mqtt aquí")

def readA(path):
    # Verificamos primero si el archivo existe antes de leerlo
    if not xbmcvfs.exists(path):
        return ""
    f = xbmcvfs.File(path, 'r')
    d = f.read()
    f.close()
    return d