# scraper_tv90.py

import os
import urllib.parse
import requests


# ============================================================
# KODI / PC
# ============================================================

debug = 0

try:
    import xbmc
    from scrapers.merge_lists import unir_listas_m3u

except ImportError:

    debug = 1

    class XBMC:

        LOGINFO = "INFO"
        LOGERROR = "ERROR"

        @staticmethod
        def log(mensaje, nivel=None):
            print(f"[{nivel}] {mensaje}")

        @staticmethod
        def getInfoLabel(valor):

            if valor == "Network.IPAddress":
                return "127.0.0.1"

            return ""

        @staticmethod
        def executebuiltin(comando):
            print(f"[KODI] Ejecutando: {comando}")

    xbmc = XBMC()

    def unir_listas_m3u(carpeta):
        return ""


# ============================================================
# CONFIGURACIÓN
# ============================================================

URL = "https://tvf90.com/status.json"

REFERER = "https://tvf90.com/"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 "
    "(KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)


# ============================================================
# OBTENER IP
# ============================================================
import time
def obtener_ip():
    intentos=0  
    # 1. Bucle de reintentos por si la interfaz de red de Android está ocupada al arrancar
    try:
        while intentos < 15:
            ip_kodi = xbmc.getInfoLabel("Network.IPAddress").strip()
            
            # Si la IP es válida y no es vacía, "Busy" o la IP de bucle local, la tomamos
            if ip_kodi and ip_kodi.lower() != "busy" and ip_kodi != "127.0.0.1" and ip_kodi != "0.0.0.0":
                xbmc.log(f"MQTT Éxito: IP de Kodi obtenida tras {intentos} reintentos -> {ip_kodi}", xbmc.LOGINFO)
                return ip_kodi
                
            intentos += 1
            time.sleep(0.5) # Esperamos medio segundo antes del próximo intento
    except:
        return "127.0.0.1"


# ============================================================
# OBTENER JSON
# ============================================================

def obtener_json(url):

    try:

        respuesta = requests.get(
            url,
            timeout=30,
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "application/json"
            }
        )

        respuesta.raise_for_status()

        return respuesta.json()

    except Exception as e:

        xbmc.log(
            f"Error obteniendo JSON TV90: {e}",
            xbmc.LOGERROR
        )

        return None


# ============================================================
# CAMBIAR URL DEL STREAM
# ============================================================

def cambiar_url_stream(url):

    """
    Cambia:

        /online.php

    por:

        /5.php

    Ejemplo:

        https://tvf90.com/online.php?stream=espn2

    pasa a:

        https://tvf90.com/5.php?stream=espn2
    """

    return url.replace(
        "/online.php",
        "/5.php"
    )


# ============================================================
# CREAR LISTA
# ============================================================

def crear_lista(carpeta_listas):

    xbmc.log(
        "Generando lista TV90",
        xbmc.LOGINFO
    )

    datos = obtener_json(URL)

    if not datos:

        xbmc.log(
            "JSON vacío",
            xbmc.LOGERROR
        )

        return

    if not isinstance(datos, dict):

        xbmc.log(
            "El JSON no tiene el formato esperado",
            xbmc.LOGERROR
        )

        return

    ip = obtener_ip()

    lista = "#EXTM3U\n"

    contador = 0

    print("-------------------------------")
    print(f"IP Detectada: {ip}")

    # ========================================================
    # RECORRER CATEGORÍAS
    # ========================================================

    for categoria, canales in datos.items():

        if not isinstance(canales, list):
            continue

        for canal in canales:

            if not isinstance(canal, dict):
                continue

            nombre = str(
                canal.get("Canal", "")
            ).strip()

            estado = str(
                canal.get("Estado", "")
            ).strip()

            url = str(
                canal.get("Link", "")
            ).strip()

            if not nombre:
                continue

            if not url:
                continue

            # ------------------------------------------------
            # SOLO CANALES ACTIVOS
            # ------------------------------------------------

            if estado.lower() != "activo":
                continue

            # ------------------------------------------------
            # CAMBIAR online.php -> 5.php
            # ------------------------------------------------

            url = cambiar_url_stream(url)

            # ------------------------------------------------
            # CODIFICAR URL
            # ------------------------------------------------

            encoded_url = urllib.parse.quote(
                url,
                safe=""
            )

            encoded_referer = urllib.parse.quote(
                REFERER,
                safe=""
            )

            # ------------------------------------------------
            # URL DEL PROXY
            # ------------------------------------------------

            proxy = (
                f"http://{ip}:8090/proxy?"
                f"url={encoded_url}"
                f"&referer={encoded_referer}"
            )

            # ------------------------------------------------
            # M3U
            # ------------------------------------------------

            lista += (
                '#EXTINF:-1 '
                f'group-title="tv90_{categoria}",'
                f'{nombre}\n'
                f'#EXTVLCOPT:http-user-agent={USER_AGENT}\n'
                f'#EXTVLCOPT:http-referrer={REFERER}\n'
                f'{proxy}\n'
            )

            contador += 1

            if debug:

                print(
                    f"[{contador}] "
                    f"{categoria} | "
                    f"{nombre}"
                )

                print(
                    f"    URL: {url}"
                )

    # ========================================================
    # COMPROBAR RESULTADOS
    # ========================================================

    if contador == 0:

        xbmc.log(
            "No se encontraron canales activos",
            xbmc.LOGERROR
        )

        return

    # ========================================================
    # GUARDAR LISTA
    # ========================================================

    archivo = os.path.join(
        carpeta_listas,
        "tv90.m3u"
    )

    try:

        with open(
            archivo,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(lista)

        xbmc.log(
            f"Lista creada: {archivo}",
            xbmc.LOGINFO
        )

    except Exception as e:

        xbmc.log(
            f"Error guardando tv90.m3u: {e}",
            xbmc.LOGERROR
        )

        return

    # ========================================================
    # UNIFICAR LISTAS
    # ========================================================

    try:

        contenido = unir_listas_m3u(
            carpeta_listas
        )

        # En PC devuelve ""
        if contenido:

            archivo_unico = os.path.join(
                carpeta_listas,
                "unicalista.m3u"
            )

            with open(
                archivo_unico,
                "w",
                encoding="utf-8"
            ) as f:

                f.write(contenido)

            xbmc.log(
                f"Lista unificada creada: "
                f"{archivo_unico}",
                xbmc.LOGINFO
            )

            xbmc.executebuiltin(
                "PVR.ReloadChannels"
            )

    except Exception as e:

        xbmc.log(
            f"Error creando unicalista.m3u: {e}",
            xbmc.LOGERROR
        )

    # ========================================================
    # INFORMACIÓN PC
    # ========================================================

    if debug:

        print("-------------------------------")
        print(
            f"Canales activos: {contador}"
        )
        print(
            f"Lista creada: {archivo}"
        )


# ============================================================
# EJECUCIÓN DIRECTA
# ============================================================

if __name__ == "__main__":

    carpeta_destino = os.path.dirname(
        os.path.abspath(__file__)
    )

    if not os.path.exists(carpeta_destino):

        os.makedirs(
            carpeta_destino
        )

    print(
        "[*] Ejecución directa detectada"
    )

    print(
        f"[*] Guardando lista en: "
        f"{carpeta_destino}"
    )

    crear_lista(
        carpeta_destino
    )
