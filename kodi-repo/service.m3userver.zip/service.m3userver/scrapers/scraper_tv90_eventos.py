# scraper_tv90_eventos.py

import os
import base64
import urllib.parse
import requests


# ============================================================
# KODI / PC
# ============================================================

debug = 0

try:
    import xbmc
    from scrapers.merge_lists import unir_listas_m3u

except ImportError:

    debug = 1

    class XBMC:

        LOGINFO = "INFO"
        LOGERROR = "ERROR"

        @staticmethod
        def log(mensaje, nivel=None):
            print(f"[{nivel}] {mensaje}")

        @staticmethod
        def getInfoLabel(valor):

            if valor == "Network.IPAddress":
                return "127.0.0.1"

            return ""

        @staticmethod
        def executebuiltin(comando):
            print(f"[KODI] Ejecutando: {comando}")

    xbmc = XBMC()

    def unir_listas_m3u(carpeta):
        return ""


# ============================================================
# CONFIGURACIÓN
# ============================================================

URL = "https://api.wqxag.com/diaries.json"

REFERER = "https://tvf90.com/"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 "
    "(KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)


# ============================================================
# OBTENER IP
# ============================================================
import time
def obtener_ip():
    intentos=0  
    # 1. Bucle de reintentos por si la interfaz de red de Android está ocupada al arrancar
    try:
        while intentos < 15:
            ip_kodi = xbmc.getInfoLabel("Network.IPAddress").strip()
            
            # Si la IP es válida y no es vacía, "Busy" o la IP de bucle local, la tomamos
            if ip_kodi and ip_kodi.lower() != "busy" and ip_kodi != "127.0.0.1" and ip_kodi != "0.0.0.0":
                xbmc.log(f"MQTT Éxito: IP de Kodi obtenida tras {intentos} reintentos -> {ip_kodi}", xbmc.LOGINFO)
                return ip_kodi
                
            intentos += 1
            time.sleep(0.5) # Esperamos medio segundo antes del próximo intento
    except:
        return "127.0.0.1"

# ============================================================
# OBTENER JSON
# ============================================================

def obtener_json(url):

    try:

        respuesta = requests.get(
            url,
            timeout=30,
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "application/json"
            }
        )

        respuesta.raise_for_status()

        return respuesta.json()

    except Exception as e:

        xbmc.log(
            f"Error obteniendo JSON eventos: {e}",
            xbmc.LOGERROR
        )

        return None


# ============================================================
# DECODIFICAR BASE64
# ============================================================

def decodificar_base64(valor):

    try:

        valor = valor.strip()

        # Corregir padding Base64
        padding = len(valor) % 4

        if padding:
            valor += "=" * (4 - padding)

        resultado = base64.b64decode(
            valor
        ).decode(
            "utf-8"
        )

        return resultado

    except Exception as e:

        xbmc.log(
            f"Error decodificando Base64: {e}",
            xbmc.LOGERROR
        )

        return ""


# ============================================================
# EXTRAER URL DEL EMBED
# ============================================================

def extraer_url_embed(embed_iframe):

    """
    Ejemplo:

    /embed/eventos.html?r=aHR0cHM6Ly90dmY5MC5jb20vMS5waHA/c3RyZWFtPWVzcG4=

    Extrae el parámetro r= y lo decodifica.
    """

    if not embed_iframe:
        return ""

    try:

        # El iframe es una URL relativa.
        # urlsplit permite obtener correctamente el query.
        partes = urllib.parse.urlsplit(
            embed_iframe
        )

        parametros = urllib.parse.parse_qs(
            partes.query
        )

        valores = parametros.get("r")

        if not valores:
            return ""

        encoded = valores[0]

        return decodificar_base64(
            encoded
        )

    except Exception as e:

        xbmc.log(
            f"Error extrayendo embed: {e}",
            xbmc.LOGERROR
        )

        return ""


# ============================================================
# CAMBIAR URL DEL STREAM
# ============================================================

def cambiar_url_stream(url):

    """
    Convierte cualquier PHP de tvf90.com a 6.php,
    conservando los parámetros.

    Ejemplos:

        https://tvf90.com/canal.php?stream=espn
        ->
        https://tvf90.com/6.php?stream=espn

        https://tvf90.com/1.php?stream=disney15
        ->
        https://tvf90.com/6.php?stream=disney15

        https://tvf90.com/2.php?stream=espn
        ->
        https://tvf90.com/6.php?stream=espn

        https://tvf90.com/plus1.php?stream=even1
        ->
        https://tvf90.com/6.php?stream=even1
    """

    try:

        partes = urllib.parse.urlsplit(
            url
        )

        nueva_url = urllib.parse.urlunsplit((
            partes.scheme,
            partes.netloc,
            "/5.php",
            partes.query,
            partes.fragment
        ))
        print(nueva_url)
        return nueva_url

    except Exception as e:

        xbmc.log(
            f"Error cambiando URL: {e}",
            xbmc.LOGERROR
        )

        return url


# ============================================================
# CREAR LISTA
# ============================================================

def crear_lista(carpeta_listas):

    xbmc.log(
        "Generando lista de eventos TV90",
        xbmc.LOGINFO
    )

    datos = obtener_json(
        URL
    )

    if not datos:

        xbmc.log(
            "JSON vacío",
            xbmc.LOGERROR
        )

        return

    if not isinstance(
        datos,
        dict
    ):

        xbmc.log(
            "Formato JSON incorrecto",
            xbmc.LOGERROR
        )

        return

    eventos = datos.get(
        "data",
        []
    )

    if not isinstance(
        eventos,
        list
    ):

        xbmc.log(
            "No se encontró data",
            xbmc.LOGERROR
        )

        return

    ip = obtener_ip()

    referer_encoded = urllib.parse.quote(
        REFERER,
        safe=""
    )

    lista = "#EXTM3U\n"

    contador = 0

    print("-------------------------------")
    print(
        f"IP Detectada: {ip}"
    )


    # ========================================================
    # RECORRER EVENTOS
    # ========================================================

    for evento_data in eventos:

        if not isinstance(
            evento_data,
            dict
        ):
            continue

        atributos = evento_data.get(
            "attributes",
            {}
        )

        if not isinstance(
            atributos,
            dict
        ):
            continue


        # ====================================================
        # INFORMACIÓN DEL EVENTO
        # ====================================================

        descripcion = str(
            atributos.get(
                "diary_description",
                "Evento"
            )
        ).strip()

        # Quitar saltos de línea
        descripcion = " ".join(
            descripcion.split()
        )


        hora = str(
            atributos.get(
                "diary_hour",
                ""
            )
        ).strip()

        # 19:30:00 -> 19:30
        if len(hora) >= 5:
            hora = hora[:5]


        # ====================================================
        # CHANNELS
        # ====================================================

        channels = atributos.get(
            "channels",
            {}
        )

        if not isinstance(
            channels,
            dict
        ):
            channels = {}

        canales_data = channels.get(
            "data",
            []
        )

        if not isinstance(
            canales_data,
            list
        ):
            canales_data = []


        # ====================================================
        # EMBEDS
        # ====================================================

        embeds = atributos.get(
            "embeds",
            {}
        )

        if not isinstance(
            embeds,
            dict
        ):
            embeds = {}

        embeds_data = embeds.get(
            "data",
            []
        )

        if not isinstance(
            embeds_data,
            list
        ):
            embeds_data = []


        # ====================================================
        # LISTA DE FUENTES
        # ====================================================

        fuentes = []


        # ====================================================
        # SI EXISTEN CHANNELS
        # ====================================================

        if canales_data:

            for canal_data in canales_data:

                if not isinstance(
                    canal_data,
                    dict
                ):
                    continue

                canal_attr = canal_data.get(
                    "attributes",
                    {}
                )

                if not isinstance(
                    canal_attr,
                    dict
                ):
                    canal_attr = {}

                nombre = str(
                    canal_attr.get(
                        "channel_name",
                        canal_attr.get(
                            "name",
                            "Canal"
                        )
                    )
                ).strip()

                url = str(
                    canal_attr.get(
                        "url",
                        canal_attr.get(
                            "link",
                            ""
                        )
                    )
                ).strip()

                if url:

                    fuentes.append(
                        (
                            nombre,
                            url
                        )
                    )


        # ====================================================
        # SI NO HAY CHANNELS -> EMBEDS
        # ====================================================

        else:

            for embed_data in embeds_data:

                if not isinstance(
                    embed_data,
                    dict
                ):
                    continue

                embed_attr = embed_data.get(
                    "attributes",
                    {}
                )

                if not isinstance(
                    embed_attr,
                    dict
                ):
                    continue


                nombre = str(
                    embed_attr.get(
                        "embed_name",
                        "Embed"
                    )
                ).strip()


                iframe = str(
                    embed_attr.get(
                        "embed_iframe",
                        ""
                    )
                ).strip()


                if not iframe:
                    continue


                # --------------------------------------------
                # Decodificar r= Base64
                # --------------------------------------------

                url_real = extraer_url_embed(
                    iframe
                )


                if not url_real:
                    continue


                # --------------------------------------------
                # CAMBIAR PHP -> 6.php
                # --------------------------------------------

                url_real = cambiar_url_stream(
                    url_real
                )


                fuentes.append(
                    (
                        nombre,
                        url_real
                    )
                )


        # ====================================================
        # CREAR ENTRADAS M3U
        # ====================================================

        for nombre, url_real in fuentes:

            if not url_real:
                continue


            # ------------------------------------------------
            # Codificar URL del stream
            # ------------------------------------------------

            url_encoded = urllib.parse.quote(
                url_real,
                safe=""
            )


            # ------------------------------------------------
            # URL LOCAL DEL PROXY
            # ------------------------------------------------

            proxy = (
                f"http://{ip}:8090/proxy?"
                f"url={url_encoded}"
                f"&referer={referer_encoded}"
            )


            # ------------------------------------------------
            # TÍTULO
            # ------------------------------------------------

            titulo = (
                f"({hora}) "
                f"{descripcion} - "
                f"{nombre}"
            )


            # ------------------------------------------------
            # M3U
            # ------------------------------------------------

            lista += (
                '#EXTINF:-1 '
                'group-title="eventos tv90",'
                f'{titulo}\n'
                f'#EXTVLCOPT:http-user-agent={USER_AGENT}\n'
                f'#EXTVLCOPT:http-referrer={REFERER}\n'
                f'{proxy}\n'
            )


            contador += 1


            if debug:

                print(
                    f"[{contador}] "
                    f"{hora} | "
                    f"{descripcion} | "
                    f"{nombre}"
                )

                print(
                    f"    Stream: {url_real}"
                )


    # ========================================================
    # COMPROBAR RESULTADOS
    # ========================================================

    if contador == 0:

        xbmc.log(
            "No se encontraron streams",
            xbmc.LOGERROR
        )

        return


    # ========================================================
    # GUARDAR LISTA
    # ========================================================

    archivo = os.path.join(
        carpeta_listas,
        "tv90_eventos.m3u"
    )


    try:

        with open(
            archivo,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(lista)


        xbmc.log(
            f"Lista creada: {archivo}",
            xbmc.LOGINFO
        )


    except Exception as e:

        xbmc.log(
            f"Error guardando lista: {e}",
            xbmc.LOGERROR
        )

        return


    # ========================================================
    # UNIFICAR LISTAS
    # ========================================================

    try:

        contenido = unir_listas_m3u(
            carpeta_listas
        )


        # En PC devuelve ""
        if contenido:

            archivo_unico = os.path.join(
                carpeta_listas,
                "unicalista.m3u"
            )


            with open(
                archivo_unico,
                "w",
                encoding="utf-8"
            ) as f:

                f.write(contenido)


            xbmc.log(
                f"Lista unificada creada: "
                f"{archivo_unico}",
                xbmc.LOGINFO
            )


            xbmc.executebuiltin(
                "PVR.ReloadChannels"
            )


    except Exception as e:

        xbmc.log(
            f"Error creando unicalista.m3u: {e}",
            xbmc.LOGERROR
        )


    # ========================================================
    # INFORMACIÓN PC
    # ========================================================

    if debug:

        print("-------------------------------")

        print(
            f"Streams encontrados: "
            f"{contador}"
        )

        print(
            f"Lista creada: {archivo}"
        )


# ============================================================
# EJECUCIÓN DIRECTA
# ============================================================

if __name__ == "__main__":

    carpeta_destino = os.path.dirname(
        os.path.abspath(__file__)
    )


    if not os.path.exists(
        carpeta_destino
    ):

        os.makedirs(
            carpeta_destino
        )


    print(
        "[*] Ejecución directa detectada"
    )


    print(
        f"[*] Guardando lista en: "
        f"{carpeta_destino}"
    )


    crear_lista(
        carpeta_destino
    )
