import re
import requests
import base64
import sys
from urllib.parse import urlparse, parse_qs

debug=0
try:
    import xmbc
except:
    debug=1
    
def debug(msg):
    print(msg)
def decode_nested_atob(texto):
    m = re.search(r'"([^"]+)"', texto)

    if not m:
        return None

    dato = m.group(1)

    veces = len(re.findall(r'atob\s*\(', texto))

    for _ in range(veces):
        dato = base64.b64decode(dato).decode("utf-8")

    return dato


def extraer_playback(url, referer="https://futbol-libres.su/"):

    try:

        r = requests.get(
            url,
            headers={
                "User-Agent": "Mozilla/5.0",
                "Referer": referer
            },
            timeout=15
        )

        r.raise_for_status()

        html = r.text
        print(html)
        patrones = [
            r'playbackURL\s*=\s*["\'](.*?)["\']',
            r'playbackUrl\s*=\s*["\'](.*?)["\']',
            r'sourceUrl\s*[:=]\s*["\'](.*?)["\']',
            r'var src\s*[:=]\s*["\'](.*?)["\']',
            r'playbackURL\s*=\s*(atob\s*\(.+?\));'
        ]

        for patron in patrones:

            m = re.search(
                patron,
                html,
                re.IGNORECASE
            )

            if m:

                resultado = m.group(1)

                if "atob" in resultado:
                    resultado = decode_nested_atob(resultado)

                if resultado:
                    return resultado.replace("\\/", "/")

        # Respaldo buscando cualquier m3u8

        m3u = re.search(
            r'https?://[^"\']+\.m3u8[^"\']*',
            html
        )

        if m3u:
            return m3u.group(0).replace("\\/", "/")

    except Exception as e:
        print("SCRAPER ERROR:", e)

    return None


def main(proxy_url):

    # Solo se utiliza cuando el archivo se ejecuta directamente

    parsed = urlparse(proxy_url)
    params = parse_qs(parsed.query)

    url = params.get("url", [None])[0]
    referer = params.get("referer", [""])[0]
    scraper = params.get("scraper", [None])[0]
    debug(url)
    debug(referer)
    debug(scraper)
    if not url:
        print("Falta el parámetro url")
        return

    resultado = extraer_playback(
        url,
        referer
    )

    if resultado:
        print(resultado)
    else:
        print("No se encontró playback")


if __name__ == "__main__":

    if len(sys.argv) < 2:
        print("Uso: python scraper.py '<url>'")
        sys.exit(1)
    
    main(sys.argv[1])
