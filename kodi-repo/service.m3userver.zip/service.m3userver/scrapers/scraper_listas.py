# scraper_listas.py

import os
import re
import requests
try:
    import xbmc
except: 
    xbmc=""
import urllib.parse

try:
    from scrapers.merge_lists import unir_listas_m3u
except:
    from merge_lists import unir_listas_m3u

# Reemplaza esta URL con la dirección RAW real de tu archivo TXT en el repositorio
URL_TXT_REPOSITORIO = "https://raw.githubusercontent.com/tvliveapp/channels/refs/heads/master/milista/listas.txt"

def obtener_ip():
    ip = ""
    if xbmc:
        ip = xbmc.getInfoLabel("Network.IPAddress")
    if not ip:
        ip = "127.0.0.1"
    return ip

myIP = obtener_ip()
if myIP:
   myIP = "http://" + myIP + ":8090"

def obtener_html(url):
    try:
        respuesta = requests.get(
            url,
            timeout=20,
            headers={
                "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
            }
        )
        respuesta.raise_for_status()
        return respuesta.text
    except Exception as e:
        if xbmc:
            xbmc.log(
                f"Error obteniendo contenido desde {url}: {e}",
                xbmc.LOGERROR
            )
        return ""

def obtener_configuracion_listas(url_txt):
    """
    Descarga el .txt y extrae pares de (nombre_archivo, url).
    Soporta formatos tipo: deportes.m3u http://url... o deportes http://url...
    """
    if xbmc:
        xbmc.log(f"Descargando archivo de configuración TXT: {url_txt}", xbmc.LOGINFO)
    contenido = obtener_html(url_txt)
    if not contenido:
        return []
    
    listas_configuradas = []
    lineas = contenido.splitlines()
    
    for linea in lineas:
        linea_limpia = linea.strip()
        # Ignorar líneas vacías o comentarios
        if not linea_limpia or linea_limpia.startswith("#"):
            continue
            
        # Dividir la línea usando cualquier cantidad de espacios o tabuladores como separador
        partes = re.split(r"\s+", linea_limpia, maxsplit=1)
        if len(partes) == 2:
            nombre = partes[0].strip()
            url = partes[1].strip()
            
            # Asegurar que el nombre tenga la extensión .m3u
            if not nombre.lower().endswith(".m3u"):
                nombre += ".m3u"
                
            listas_configuradas.append((nombre, url))
            
    return listas_configuradas

def crear_lista(carpeta_listas):
    if xbmc:
        xbmc.log(
            "Generando múltiples listas desde repositorio (scraper_listas)",
            xbmc.LOGINFO
        )

    # 1. Leer el archivo de texto remoto para obtener los nombres y las URLs
    config_listas = obtener_configuracion_listas(URL_TXT_REPOSITORIO)
    
    if not config_listas:
        if xbmc:
            xbmc.log(
                "No se encontraron configuraciones válidas en el archivo .txt remoto",
                xbmc.LOGERROR
            )
        return

    archivos_creados = 0

    # 2. Procesar y guardar cada lista con su propio nombre asignado
    for nombre_archivo, url_fuente in config_listas:
        if xbmc:
            xbmc.log(f"Procesando fuente: {nombre_archivo} -> {url_fuente}", xbmc.LOGINFO)
        
        html_actual = obtener_html(url_fuente)
        if not html_actual:
            continue

        # Asegurar que el contenido empiece con #EXTM3U
        if not html_actual.strip().startswith("#EXTM3U"):
            html_actual = "#EXTM3U\n" + html_actual

        ruta_salida_lista = os.path.join(carpeta_listas, nombre_archivo)
        
        # Guardar de manera independiente sustituyendo 'proxyIP'
        try:
            with open(ruta_salida_lista, "w", encoding="utf-8") as f:
                f.write(html_actual.replace("proxyIP", myIP))
            archivos_creados += 1
            if xbmc:
                xbmc.log(f"Archivo guardado individualmente: {ruta_salida_lista}", xbmc.LOGINFO)
        except Exception as e:
            if xbmc:
                xbmc.log(f"Error guardando archivo {nombre_archivo}: {e}", xbmc.LOGERROR)

    if archivos_creados == 0:
        if xbmc:
            xbmc.log("No se pudo descargar ni guardar ninguna de las listas indicadas", xbmc.LOGERROR)
        return

    # 3. Generar la unicalista unificada uniendo todos los archivos creados en la carpeta
    try:
        contenido_unificado = unir_listas_m3u(
            carpeta_listas
        )

        archivo_unico = os.path.join(
            carpeta_listas,
            "unicalista.m3u"
        )

        with open(
            archivo_unico,
            "w",
            encoding="utf-8"
        ) as f:
            f.write(
                contenido_unificado
            )
            
        if xbmc:
            xbmc.log(
                f"Lista unificada creada con scraper_listas: {archivo_unico}",
                xbmc.LOGINFO
            )
            xbmc.executebuiltin("PVR.ReloadChannels")
    except Exception as e:
        if xbmc:
            xbmc.log(
                f"Error creando unicalista.m3u: {e}",
                xbmc.LOGERROR
            )
if __name__ == "__main__":



    carpeta_destino = os.path.dirname(

        os.path.abspath(__file__)

    )



    print(

        "[*] Ejecución directa detectada."

    )



    print(

        f"[*] Guardando lista en: "

        f"{carpeta_destino}"

    )



    crear_lista(

        carpeta_destino

    )
