import os
import json
import requests
import urllib.parse

debug = 0

# Intentar cargar XBMC/Kodi
try:
    import xbmc
    from scrapers.merge_lists import unir_listas_m3u

except ImportError:
    # Simulación para ejecutar en PC
    debug = 1

    class XBMC:
        LOGINFO = "INFO"
        LOGERROR = "ERROR"

        @staticmethod
        def log(mensaje, nivel=None):
            print(f"[{nivel}] {mensaje}")

        @staticmethod
        def getInfoLabel(valor):
            if valor == "Network.IPAddress":
                return "127.0.0.1"
            return ""

        @staticmethod
        def executebuiltin(comando):
            print(f"[KODI] Ejecutando: {comando}")

    xbmc = XBMC()

    def unir_listas_m3u(carpeta):
        return ""


# ============================================================
# CONFIGURACIÓN
# ============================================================

URL_EVENTOS = "https://streamtp-golden1.click/eventos.json"

REFERER = "https://streamtp-golden1.click/"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36"
)


# ============================================================
# UTILIDADES
# ============================================================

import time
def obtener_ip():
    intentos=0  
    # 1. Bucle de reintentos por si la interfaz de red de Android está ocupada al arrancar
    try:
        while intentos < 15:
            ip_kodi = xbmc.getInfoLabel("Network.IPAddress").strip()
            
            # Si la IP es válida y no es vacía, "Busy" o la IP de bucle local, la tomamos
            if ip_kodi and ip_kodi.lower() != "busy" and ip_kodi != "127.0.0.1" and ip_kodi != "0.0.0.0":
                xbmc.log(f"MQTT Éxito: IP de Kodi obtenida tras {intentos} reintentos -> {ip_kodi}", xbmc.LOGINFO)
                return ip_kodi
                
            intentos += 1
            time.sleep(0.5) # Esperamos medio segundo antes del próximo intento
    except:
        return "127.0.0.1"



def obtener_eventos(url):
    try:

        respuesta = requests.get(
            url,
            timeout=20,
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "application/json"
            }
        )

        respuesta.raise_for_status()

        return respuesta.json()

    except Exception as e:
        xbmc.log(
            f"Error obteniendo eventos StreamTP: {e}",
            xbmc.LOGERROR
        )

        return []


def limpiar_texto(texto):
    if not texto:
        return ""

    return str(texto).strip()


# ============================================================
# CREAR LISTA M3U
# ============================================================

def crear_lista(carpeta_listas):

    xbmc.log(
        "Generando lista StreamTP Eventos",
        xbmc.LOGINFO
    )

    eventos = obtener_eventos(URL_EVENTOS)

    if not eventos:
        xbmc.log(
            "No se encontraron eventos",
            xbmc.LOGERROR
        )
        return

    if not isinstance(eventos, list):
        xbmc.log(
            "El JSON de eventos no tiene formato de lista",
            xbmc.LOGERROR
        )
        return

    lista = "#EXTM3U\n"

    ip = obtener_ip()

    print("-------------------------------")
    print(f"IP Detectada: {ip}")
    print(f"Eventos encontrados: {len(eventos)}")

    referer_encoded = urllib.parse.quote(
        REFERER,
        safe=""
    )

    contador = 0

    for evento in eventos:

        if not isinstance(evento, dict):
            continue

        titulo = limpiar_texto(
            evento.get("title")
        )

        hora = limpiar_texto(
            evento.get("time")
        )

        categoria = limpiar_texto(
            evento.get("category")
        )
        categoria="eventos streamtp"
        estado = limpiar_texto(
            evento.get("status")
        )

        url = limpiar_texto(
            evento.get("link")
        )

        idioma = limpiar_texto(
            evento.get("language")
        )

        if not titulo or not url:
            continue

        # ----------------------------------------------------
        # Nombre del canal
        # ----------------------------------------------------

        nombre = titulo

        if hora:
            nombre = f" {hora} "+nombre

        if idioma:
            nombre += f" [{idioma}]"

        # ----------------------------------------------------
        # URL para el proxy
        # ----------------------------------------------------

        url_encoded = urllib.parse.quote(
            url,
            safe=""
        )

        proxy = (
            f"http://{ip}:8090/proxy?"
            f"url={url_encoded}"
            f"&referer={referer_encoded}"
        )

        # ----------------------------------------------------
        # Información adicional
        # ----------------------------------------------------

        if categoria:
            group_title = categoria
        else:
            group_title = "StreamTP Eventos"

        # ----------------------------------------------------
        # M3U
        # ----------------------------------------------------

        lista += (
            '#EXTINF:-1 '
            f'group-title="{group_title}",'
            f'{nombre}\n'
            f'#EXTVLCOPT:http-user-agent={USER_AGENT}\n'
            f'#EXTVLCOPT:http-referrer={REFERER}\n'
            f'{proxy}\n'
        )

        contador += 1

        # Debug
        if debug:
            print(
                f"[{contador}] "
                f"{titulo} | "
                f"{hora} | "
                f"{estado} | "
                f"{url}"
            )

    if contador == 0:

        xbmc.log(
            "No se pudieron crear canales",
            xbmc.LOGERROR
        )

        return

    # ========================================================
    # GUARDAR LISTA
    # ========================================================

    archivo_eventos = os.path.join(
        carpeta_listas,
        "streamtp_eventos.m3u"
    )

    try:

        with open(
            archivo_eventos,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(lista)

        xbmc.log(
            f"Lista creada: {archivo_eventos}",
            xbmc.LOGINFO
        )

    except Exception as e:

        xbmc.log(
            f"Error guardando streamtp_eventos.m3u: {e}",
            xbmc.LOGERROR
        )

        return

    # ========================================================
    # UNIFICAR LISTAS
    # ========================================================

    try:

        contenido_unificado = unir_listas_m3u(
            carpeta_listas
        )

        if contenido_unificado:

            archivo_unico = os.path.join(
                carpeta_listas,
                "unicalista.m3u"
            )

            with open(
                archivo_unico,
                "w",
                encoding="utf-8"
            ) as f:

                f.write(contenido_unificado)

            xbmc.log(
                f"Lista unificada creada: {archivo_unico}",
                xbmc.LOGINFO
            )

            xbmc.executebuiltin(
                "PVR.ReloadChannels"
            )

    except Exception as e:

        xbmc.log(
            f"Error creando unicalista.m3u: {e}",
            xbmc.LOGERROR
        )


# ============================================================
# DEBUG
# ============================================================

def debug_print(msg):
    print(msg)


# ============================================================
# EJECUCIÓN DIRECTA
# ============================================================

if __name__ == "__main__":

    carpeta_destino = os.path.dirname(
        os.path.abspath(__file__)
    )

    if not os.path.exists(carpeta_destino):
        os.makedirs(carpeta_destino)

    print(
        "[*] Ejecución directa detectada."
    )

    print(
        f"[*] Guardando lista en: {carpeta_destino}"
    )

    crear_lista(carpeta_destino)
