
import os
import requests
import urllib.parse
import json
debug = 0

# ============================================================
# INTENTAR CARGAR XBMC/KODI
# ============================================================

try:
    import xbmc

except ImportError:

    debug = 1

    class XBMC:

        LOGINFO = "INFO"
        LOGERROR = "ERROR"

        @staticmethod
        def log(mensaje, nivel=None):
            print(f"[{nivel}] {mensaje}")

        @staticmethod
        def getInfoLabel(valor):
            if valor == "Network.IPAddress":
                return "127.0.0.1"
            return ""

        @staticmethod
        def executebuiltin(comando):
            print(f"[KODI] Ejecutando: {comando}")

    xbmc = XBMC()

# ============================================================
# CONFIGURACIÓN
# ============================================================

URL_EVENTOS = "https://streamx723.sbs/json/agenda888.json"

REFERER = "https://streamx723.sbs/"

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 "
    "(KHTML, like Gecko) "
    "Chrome/131.0.0.0 Safari/537.36"
)

# ============================================================
# OBTENER IP LOCAL
# ============================================================

def obtener_ip():

    try:
        ip = xbmc.getInfoLabel(
            "Network.IPAddress"
        )
    except Exception:
        ip = ""

    if not ip:
        ip = "127.0.0.1"

    return ip

# ============================================================
# OBTENER JSON
# ============================================================

def obtener_eventos(url):

    try:

        respuesta = requests.get(
            url,
            timeout=20,
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "application/json",
                "Referer": REFERER
            }
        )

        respuesta.raise_for_status()

        datos = respuesta.json()

        return datos

    except Exception as e:

        xbmc.log(
            f"Error obteniendo agenda StreamX: {e}",
            xbmc.LOGERROR
        )

        return []

# ============================================================
# LIMPIAR TEXTO
# ============================================================

def limpiar_texto(texto):

    if texto is None:
        return ""

    return str(texto).strip()

# ============================================================
# OBTENER NOMBRE DEL CANAL
# ============================================================

def obtener_nombre_canal(url):

    try:

        parsed = urllib.parse.urlparse(url)

        parametros = urllib.parse.parse_qs(
            parsed.query
        )

        # ----------------------------------------------------
        # URLs CON ?channel=
        # ----------------------------------------------------

        if "channel" in parametros:

            canal = parametros["channel"][0]

        else:

            # ------------------------------------------------
            # URLs TIPO /channel/nombre.html
            # ------------------------------------------------

            archivo = os.path.basename(
                parsed.path
            )

            canal = os.path.splitext(
                archivo
            )[0]

        canal = limpiar_texto(canal)

        if not canal:
            return ""

        # ----------------------------------------------------
        # NOMBRES PERSONALIZADOS
        # ----------------------------------------------------

        nombres = {

            "tnt3uk": "TNT 3 UK",
            "tntuk": "TNT UK",

            "disney1": "Disney",
            "disney": "Disney",

            "foxone1": "FOX One",
            "foxone": "FOX One",

            "espn": "ESPN",
            "espn1": "ESPN",

            "espn2": "ESPN 2",
            "espn3": "ESPN 3",
            "espn4": "ESPN 4",
            "espn5": "ESPN 5",

            "fox": "FOX",
            "fox1": "FOX",

            "tnt": "TNT",
            "tnt1": "TNT",
            "tnt2": "TNT 2",
            "tnt3": "TNT 3"
        }

        canal_lower = canal.lower()

        if canal_lower in nombres:
            return nombres[canal_lower]

        # ----------------------------------------------------
        # LIMPIEZA GENÉRICA
        # ----------------------------------------------------

        canal = canal.replace("_", " ")
        canal = canal.replace("-", " ")

        resultado = ""

        for i, caracter in enumerate(canal):

            if (
                caracter.isdigit()
                and i > 0
                and canal[i - 1].isalpha()
            ):
                resultado += " "

            resultado += caracter

        return resultado.upper()

    except Exception:

        return ""

# ============================================================
# CREAR NOMBRE DEL EVENTO
# ============================================================

def crear_nombre(
    titulo,
    hora,
    estado,
    canal
):

    nombre = titulo

    if hora:
        nombre = f"{hora} {nombre}"

    if canal:
        nombre += f" [{canal}]"

    if estado:
        nombre += f" [{estado}]"

    return nombre

# ============================================================
# ESCAPAR TEXTO PARA M3U
# ============================================================

def escapar_m3u(texto):

    if not texto:
        return ""

    return (
        str(texto)
        .replace('"', "'")
        .replace("\n", " ")
        .replace("\r", " ")
    )

# ============================================================
# CREAR LISTA M3U
# ============================================================

def crear_lista(carpeta_destino):

    xbmc.log(
        "Generando lista StreamX",
        xbmc.LOGINFO
    )

    # --------------------------------------------------------
    # OBTENER EVENTOS
    # --------------------------------------------------------

    eventos = obtener_eventos(
        URL_EVENTOS
    )

    if not eventos:

        xbmc.log(
            "No se encontraron eventos StreamX",
            xbmc.LOGERROR
        )

        return False

    if not isinstance(eventos, list):

        xbmc.log(
            "El JSON de StreamX no tiene formato de lista",
            xbmc.LOGERROR
        )

        return False

    # --------------------------------------------------------
    # OBTENER IP
    # --------------------------------------------------------

    ip = obtener_ip()

    print("--------------------------------")
    print("       SCRAPER STREAMX")
    print("--------------------------------")
    print(f"IP detectada: {ip}")
    print(f"Eventos encontrados: {len(eventos)}")

    # --------------------------------------------------------
    # CODIFICAR REFERER
    # --------------------------------------------------------

    referer_encoded = urllib.parse.quote(
        REFERER,
        safe=""
    )

    # --------------------------------------------------------
    # CABECERA M3U
    # --------------------------------------------------------

    lista = "#EXTM3U\n"

    contador = 0

    # ========================================================
    # RECORRER EVENTOS
    # ========================================================

    for evento in eventos:

        if not isinstance(evento, dict):
            continue

        # ----------------------------------------------------
        # DATOS DEL JSON
        # ----------------------------------------------------

        categoria = limpiar_texto(
            evento.get("category")
        )

        titulo = limpiar_texto(
            evento.get("title")
        )

        hora = limpiar_texto(
            evento.get("time")
        )

        estado = limpiar_texto(
            evento.get("status")
        )

        fecha = limpiar_texto(
            evento.get("date")
        )

        url = limpiar_texto(
            evento.get("link")
        )

        # ----------------------------------------------------
        # VALIDAR
        # ----------------------------------------------------

        if not titulo:
            continue

        if not url:
            continue

        # ----------------------------------------------------
        # OBTENER CANAL
        # ----------------------------------------------------

        canal = obtener_nombre_canal(
            url
        )

        # ----------------------------------------------------
        # CREAR NOMBRE
        # ----------------------------------------------------

        nombre = crear_nombre(
            titulo,
            hora,
            estado,
            canal
        )

        nombre = escapar_m3u(
            nombre
        )

        categoria = escapar_m3u(
            categoria
        )

        # ----------------------------------------------------
        # GRUPO
        # ----------------------------------------------------

        if categoria:

            group_title = (
                f"StreamX {categoria}"
            )

        else:

            group_title = (
                "StreamX Eventos"
            )

        group_title = escapar_m3u(
            group_title
        )

        # ----------------------------------------------------
        # CODIFICAR URL ORIGINAL
        # ----------------------------------------------------

        url_encoded = urllib.parse.quote(
            url,
            safe=""
        )

        # ----------------------------------------------------
        # CREAR URL PARA PROXY
        # ----------------------------------------------------

        proxy = (
            f"http://{ip}:8090/proxy?"
            f"url={url_encoded}"
            f"&referer={referer_encoded}"
            f"&scraper=streamx"
        )

        # ----------------------------------------------------
        # ESCRIBIR EN M3U
        # ----------------------------------------------------

        lista += (
            '#EXTINF:-1 '
            f'group-title="{group_title}",'
            f'{nombre}\n'
            f'#EXTVLCOPT:http-user-agent={USER_AGENT}\n'
            f'#EXTVLCOPT:http-referrer={REFERER}\n'
            f'{proxy}\n'
        )

        contador += 1

        # ----------------------------------------------------
        # DEBUG
        # ----------------------------------------------------

        if debug:

            print(
                f"[{contador}] "
                f"{hora} | "
                f"{titulo} | "
                f"{canal} | "
                f"{categoria} | "
                f"{estado} | "
                f"{fecha}"
            )

    # ========================================================
    # COMPROBAR CANALES
    # ========================================================

    if contador == 0:

        xbmc.log(
            "No se pudieron crear canales StreamX",
            xbmc.LOGERROR
        )

        return False

    # ========================================================
    # CREAR CARPETA
    # ========================================================

    try:

        if not os.path.exists(
            carpeta_destino
        ):

            os.makedirs(
                carpeta_destino
            )

    except Exception as e:

        xbmc.log(
            f"Error creando carpeta: {e}",
            xbmc.LOGERROR
        )

        return False

    # ========================================================
    # GUARDAR M3U
    # ========================================================

    archivo = os.path.join(
        carpeta_destino,
        "streamx_eventos.m3u"
    )

    try:

        with open(
            archivo,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(lista)

        xbmc.log(
            f"Lista StreamX creada: {archivo}",
            xbmc.LOGINFO
        )

        print("--------------------------------")
        print(f"Canales creados: {contador}")
        print(f"Archivo: {archivo}")
        print("--------------------------------")

    except Exception as e:

        xbmc.log(
            f"Error guardando streamx_eventos.m3u: {e}",
            xbmc.LOGERROR
        )

        return False

    # ========================================================
    # RECARGAR CANALES DE KODI
    # ========================================================

    try:

        xbmc.executebuiltin(
            "PVR.ReloadChannels"
        )

    except Exception as e:

        xbmc.log(
            f"Error recargando PVR: {e}",
            xbmc.LOGERROR
        )

    return True


import base64
import re


# ============================================================
# EXTRAER PLAYBACK URL
# ============================================================

def extraer_playback(url):

    try:

        xbmc.log(
            f"Extrayendo playback: {url}",
            xbmc.LOGINFO
        )

        respuesta = requests.get(
            url,
            timeout=20,
            headers={
                "User-Agent": USER_AGENT,
                "Referer": REFERER
            }
        )

        respuesta.raise_for_status()

        html = respuesta.text

        # ====================================================
        # BUSCAR ARRAY DE PLAYBACK
        #
        # Ejemplos:
        #
        # WF = [[...], [...]];
        # rC = [[...], [...]];
        # ====================================================

        patron_array = (
            r'([A-Za-z_$][\w$]*)'
            r'\s*=\s*'
            r'(\[\[.*?\]\])'
            r'\s*;'
        )

        coincidencias = re.findall(
            patron_array,
            html,
            re.DOTALL
        )

        if not coincidencias:

            xbmc.log(
                "No se encontró el array de playback",
                xbmc.LOGERROR
            )

            return ""

        variable_array = None
        texto_array = None

        # ----------------------------------------------------
        # Buscar el array que contiene elementos tipo:
        #
        # [numero, "base64"]
        # ----------------------------------------------------

        for nombre_variable, array_texto in coincidencias:

            if re.search(
                r'\[\s*\d+\s*,\s*["\'][A-Za-z0-9+/=]+["\']\s*\]',
                array_texto
            ):

                variable_array = (
                    nombre_variable
                )

                texto_array = array_texto

                break

        if not texto_array:

            xbmc.log(
                "No se encontró un array válido",
                xbmc.LOGERROR
            )

            return ""

        # ====================================================
        # CONVERTIR ARRAY JAVASCRIPT A PYTHON
        # ====================================================

        try:

            # El contenido mostrado usa strings con comillas
            # dobles, por lo que json.loads funciona.
            wf = json.loads(
                texto_array
            )

        except Exception as e:

            xbmc.log(
                f"Error convirtiendo array: {e}",
                xbmc.LOGERROR
            )

            return ""

        if not isinstance(wf, list):

            xbmc.log(
                "El array de playback no es una lista",
                xbmc.LOGERROR
            )

            return ""

        # ====================================================
        # ORDENAR
        #
        # JavaScript:
        #
        # WF.sort((a,b) => a[0] - b[0]);
        # ====================================================

        try:

            wf.sort(
                key=lambda x: int(x[0])
            )

        except Exception as e:

            xbmc.log(
                f"Error ordenando playback: {e}",
                xbmc.LOGERROR
            )

            return ""

        # ====================================================
        # BUSCAR LAS DOS FUNCIONES QUE DEVUELVEN LOS VALORES
        #
        # Ejemplo:
        #
        # function vpAqb() {
        #     return 63818;
        # }
        #
        # function MTyCA() {
        #     return 766585;
        # ====================================================

        patron_funciones = (
            r'function\s+'
            r'([A-Za-z_$][\w$]*)'
            r'\s*\(\s*\)'
            r'\s*\{'
            r'\s*return\s+'
            r'(\d+)'
            r'\s*;?\s*'
            r'\}'
        )

        funciones = re.findall(
            patron_funciones,
            html,
            re.DOTALL
        )

        if len(funciones) < 2:

            xbmc.log(
                "No se encontraron las funciones de clave",
                xbmc.LOGERROR
            )

            return ""

        # ====================================================
        # BUSCAR LA EXPRESIÓN:
        #
        # var k = funcion1() + funcion2();
        #
        # Esto evita depender de los nombres.
        # ====================================================

        patron_k = (
            r'(?:var|let|const)\s+'
            r'([A-Za-z_$][\w$]*)'
            r'\s*=\s*'
            r'([A-Za-z_$][\w$]*)'
            r'\s*\(\s*\)'
            r'\s*\+\s*'
            r'([A-Za-z_$][\w$]*)'
            r'\s*\(\s*\)'
        )

        coincidencia_k = re.search(
            patron_k,
            html,
            re.DOTALL
        )

        if coincidencia_k:

            funcion_1 = (
                coincidencia_k.group(2)
            )

            funcion_2 = (
                coincidencia_k.group(3)
            )

        else:

            # ------------------------------------------------
            # Si no encontramos "var k = ..."
            # buscamos los nombres de las dos funciones
            # ------------------------------------------------

            funcion_1 = funciones[0][0]
            funcion_2 = funciones[1][0]

        # ====================================================
        # OBTENER VALORES DE LAS FUNCIONES
        # ====================================================

        valores_funciones = {}

        for nombre, valor in funciones:

            try:

                valores_funciones[
                    nombre
                ] = int(valor)

            except Exception:

                continue

        if (
            funcion_1 not in valores_funciones
            or
            funcion_2 not in valores_funciones
        ):

            xbmc.log(
                "No se pudieron obtener los valores de k",
                xbmc.LOGERROR
            )

            return ""

        valor_1 = valores_funciones[
            funcion_1
        ]

        valor_2 = valores_funciones[
            funcion_2
        ]

        k = valor_1 + valor_2

        # ====================================================
        # DECODIFICAR PLAYBACK
        # ====================================================

        playback_url = ""

        for elemento in wf:

            if (
                not isinstance(elemento, list)
                or len(elemento) < 2
            ):

                continue

            valor = elemento[1]

            try:

                # ------------------------------------------------
                # Base64
                # ------------------------------------------------

                decodificado = (
                    base64.b64decode(
                        valor
                    )
                    .decode(
                        "utf-8",
                        errors="ignore"
                    )
                )

                # ------------------------------------------------
                # Equivalente a:
                #
                # atob(v).replace(/\D/g, '')
                # ------------------------------------------------

                numeros = re.sub(
                    r"\D",
                    "",
                    decodificado
                )

                if not numeros:

                    continue

                numero = int(
                    numeros
                )

                # ------------------------------------------------
                # Equivalente a:
                #
                # String.fromCharCode(
                #     numero - k
                # )
                # ------------------------------------------------

                caracter = chr(
                    numero - k
                )

                playback_url += caracter

            except Exception as e:

                xbmc.log(
                    f"Error procesando elemento WF: {e}",
                    xbmc.LOGERROR
                )

        # ====================================================
        # LIMPIAR RESULTADO
        # ====================================================

        playback_url = playback_url.strip()

        if not playback_url:

            xbmc.log(
                "El playbackURL está vacío",
                xbmc.LOGERROR
            )

            return ""

        # ====================================================
        # DEBUG
        # ====================================================

        if debug:

            print(
                "--------------------------------"
            )

            print(
                f"Array: {variable_array}"
            )

            print(
                f"Función 1: {funcion_1} = {valor_1}"
            )

            print(
                f"Función 2: {funcion_2} = {valor_2}"
            )

            print(
                f"K: {k}"
            )

            print(
                f"Playback: {playback_url}"
            )

            print(
                "--------------------------------"
            )

        xbmc.log(
            "Playback URL obtenido correctamente",
            xbmc.LOGINFO
        )

        return playback_url

    except Exception as e:

        xbmc.log(
            f"Error extrayendo playback: {e}",
            xbmc.LOGERROR
        )

        return ""



# ============================================================
# EJECUCIÓN DIRECTA
# ============================================================

if __name__ == "__main__":

    carpeta_destino = os.path.dirname(
        os.path.abspath(__file__)
    )

    print(
        "[*] Ejecución directa detectada."
    )

    print(
        f"[*] Guardando lista en: "
        f"{carpeta_destino}"
    )

    crear_lista(
        carpeta_destino
    )
    playback_url = extraer_playback("https://streamx305.sbs/global1.php?channel=disney3")
    print(playback_url)
    

