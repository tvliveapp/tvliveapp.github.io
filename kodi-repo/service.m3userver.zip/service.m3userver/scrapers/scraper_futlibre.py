# scraper_futlibre.py

import os
import re
import base64
import urllib.parse
import requests


# ============================================================
# KODI / PC
# ============================================================

debug = 0

try:
    import xbmc
    from scrapers.merge_lists import unir_listas_m3u

except ImportError:

    # Estamos ejecutando fuera de Kodi
    debug = 1

    class XBMC:

        LOGINFO = "INFO"
        LOGERROR = "ERROR"

        @staticmethod
        def log(mensaje, nivel=None):
            print(f"[{nivel}] {mensaje}")

        @staticmethod
        def getInfoLabel(valor):

            if valor == "Network.IPAddress":
                return "127.0.0.1"

            return ""

        @staticmethod
        def executebuiltin(comando):
            print(f"[KODI] Ejecutando: {comando}")


    xbmc = XBMC()


    # Simulación para PC
    def unir_listas_m3u(carpeta):
        return ""


# ============================================================
# CONFIGURACIÓN
# ============================================================

URL = "https://futbollibretvhd.org/agenda"

REFERER = "https://futbollibretvhd.org/"

referer = urllib.parse.quote(
    REFERER
)


# ============================================================
# OBTENER IP
# ============================================================

def obtener_ip():

    try:

        ip = xbmc.getInfoLabel(
            "Network.IPAddress"
        )

    except Exception:

        ip = ""

    if not ip:

        ip = "127.0.0.1"

    return ip


# ============================================================
# OBTENER HTML
# ============================================================

def obtener_html(url, max_redirects=5):

    try:

        r = requests.get(
            url,
            timeout=30,
            allow_redirects=True,
            headers={
                "User-Agent":
                "Mozilla/5.0"
            }
        )

        if r.status_code != 200:

            raise Exception(
                f"HTTP {r.status_code}"
            )

        return r.text

    except Exception as e:

        xbmc.log(
            f"Error HTML: {e}",
            xbmc.LOGERROR
        )

        return ""


# ============================================================
# CREAR LISTA
# ============================================================

def crear_lista(carpeta_listas):

    xbmc.log(
        "Generando lista Futbol Libre",
        xbmc.LOGINFO
    )

    html = obtener_html(URL)

    if not html:
        xbmc.log(
            "HTML vacío",
            xbmc.LOGERROR
        )
        return

    ip = obtener_ip()

    lista = "#EXTM3U\n"

    regex_evento = (
        r'<li class="[^"]+">'
        r'([\s\S]*?)'
        r'</ul>\s*</li>'
    )

    eventos = re.findall(
        regex_evento,
        html
    )

    contador = 0

    for bloque in eventos:

        evento = "Desconocido"
        hora = "??:??"

        # ----------------------------------------------------
        # Nombre del evento
        # ----------------------------------------------------

        nombre = re.search(
            r'<a href="#">([\s\S]*?)<span class="t">',
            bloque
        )

        # ----------------------------------------------------
        # Hora
        # ----------------------------------------------------

        hora_match = re.search(
            r'<span class="t">([^<]+)</span>',
            bloque
        )

        if nombre:

            evento = re.sub(
                r"\s+",
                " ",
                nombre.group(1)
            ).strip()

        if hora_match:

            hora = hora_match.group(1).strip()

        # ----------------------------------------------------
        # Canales
        # ----------------------------------------------------

        links = re.finditer(

            r'href="[^"]*\?r=([^"]+)"'
            r'[^>]*>([^<]+)'
            r'<span>([^<]+)</span>',

            bloque

        )

        for link in links:

            base64_url = link.group(1)

            canal = link.group(2).strip()

            calidad = link.group(3).strip()

            # ------------------------------------------------
            # Decodificar URL
            # ------------------------------------------------

            try:

                real = base64.b64decode(
                    base64_url
                ).decode(
                    "utf-8"
                )

            except Exception:

                continue

            # ------------------------------------------------
            # Codificar URL para proxy
            # ------------------------------------------------

            encoded = urllib.parse.quote(
                real
            )

            proxy = (
                f"http://{ip}:8090/proxy?"
                f"url={encoded}"
                f"&referer={referer}"
            )

            # ------------------------------------------------
            # Agregar canal a M3U
            # ------------------------------------------------

            lista += (
                '#EXTINF:-1 '
                'group-title="eventos futbol libre",'
                f'({hora}) '
                f'{evento} - '
                f'{canal} '
                f'[{calidad}]\n'
                f'{proxy}\n'
            )

            contador += 1

    # ========================================================
    # GUARDAR LISTA
    # ========================================================

    archivo = os.path.join(
        carpeta_listas,
        "futlibreEV.m3u"
    )

    try:

        with open(
            archivo,
            "w",
            encoding="utf-8"
        ) as f:

            f.write(lista)

        xbmc.log(
            f"Lista creada: {archivo}",
            xbmc.LOGINFO
        )

    except Exception as e:

        xbmc.log(
            f"Error guardando lista: {e}",
            xbmc.LOGERROR
        )

        return

    # ========================================================
    # UNIFICAR LISTAS
    # ========================================================

    try:

        contenido = unir_listas_m3u(
            carpeta_listas
        )

        # En PC la función simulada devuelve ""
        if contenido:

            archivoUl = os.path.join(
                carpeta_listas,
                "unicalista.m3u"
            )

            with open(
                archivoUl,
                "w",
                encoding="utf-8"
            ) as f:

                f.write(contenido)

            xbmc.log(
                f"Lista unificada creada: {archivoUl}",
                xbmc.LOGINFO
            )

            xbmc.executebuiltin(
                "PVR.ReloadChannels"
            )

    except Exception as e:

        xbmc.log(
            f"Error creando unicalista.m3u: {e}",
            xbmc.LOGERROR
        )

    # ========================================================
    # INFORMACIÓN EN PC
    # ========================================================

    if debug:

        print("-------------------------------")
        print(f"IP detectada: {ip}")
        print(f"Eventos/canales encontrados: {contador}")
        print(f"Lista: {archivo}")


# ============================================================
# EJECUCIÓN DIRECTA
# ============================================================

if __name__ == "__main__":

    carpeta_destino = os.path.dirname(
        os.path.abspath(__file__)
    )

    if not os.path.exists(carpeta_destino):

        os.makedirs(
            carpeta_destino
        )

    print(
        "[*] Ejecución directa detectada"
    )

    print(
        f"[*] Guardando lista en: "
        f"{carpeta_destino}"
    )

    crear_lista(
        carpeta_destino
    )
