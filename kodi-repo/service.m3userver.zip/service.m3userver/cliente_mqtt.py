import xbmc
import xbmcgui
import json
import threading
import time
import uuid  # Módulo nativo para obtener la dirección MAC a nivel de hardware

# Importamos la clase Client desde tu archivo local mqtt_kodi.py
from lib import client as mqtt

# ============================================================
# CONFIGURACIÓN DEL BROKER (Modifica con tus datos)
# ============================================================
MQTT_BROKER = "broker.hivemq.com"
MQTT_PUERTO = 1883
MQTT_TOPIC_SUB = "kodi/comandos/m3userver"
MQTT_TOPIC_PUB = "kodi/estado/m3userver"

MQTT_USER = None
MQTT_PASS = None

# Variables de control de estado interno
_instancia_cliente = None
esta_conectado = False
_callback_externo = None

# Flag para saber si el Addon se está cerrando por completo y evitar reconexiones infinitas zombies
_abortando_servicio = False 


mqttMac=""
   
def getMAC():
    global mqttMac
    return mqttMac
def obtener_mac_dispositivo():
    """
    Intenta leer la MAC desde la API de Kodi filtrando estados 'Busy'.
    Si falla o expira el tiempo, utiliza el módulo nativo uuid de Python.
    """
    intentos = 0
    # 1. Intentar por la vía oficial de Kodi (Espera que Android despierte la red)
    while intentos < 10:
        mac_kodi = xbmc.getInfoLabel("Network.MacAddress").strip()
        if mac_kodi and mac_kodi.lower() != "busy" and mac_kodi != "00:00:00:00:00:00":
            xbmc.log(f"MQTT MAC: Extraída de Kodi exitosamente -> {mac_kodi}", xbmc.LOGINFO)
            return mac_kodi
        intentos += 1
        time.sleep(0.5)

    # 2. MÉTODO DE RESPALDO: Extraer la dirección de hardware nativa usando uuid
    try:
        node = uuid.getnode()
        # Formatear el entero de 48 bits a formato estándar hexadecimal XX:XX:XX:XX:XX:XX
        mac_hardware = ':'.join(['{:02x}'.format((node >> ele) & 0xff) for ele in range(0, 8*6, 8)][::-1])
        if mac_hardware and mac_hardware != "00:00:00:00:00:00":
            xbmc.log(f"MQTT MAC: Kodi reportó Busy. Usando MAC nativa de Hardware -> {mac_hardware}", xbmc.LOGINFO)
            return mac_hardware
    except Exception as e:
        xbmc.log(f"MQTT MAC Error: No se pudo calcular la dirección MAC de hardware: {e}", xbmc.LOGDEBUG)

    return "Desconocida"


# ============================================================
# MANEJO DE EVENTOS MQTT CON RECONEXIÓN AUTOMÁTICA
# ============================================================
def al_conectar(client, userdata, flags, rc=None):
    """Callback invocado automáticamente al conectarse exitosamente"""
    global esta_conectado,  mqttMac
    codigo = rc if rc is not None else flags
    
    if codigo == 0:
        esta_conectado = True
        xbmc.log(f"MQTT Éxito: Conectado al Broker. Suscribiendo a: {MQTT_TOPIC_SUB}", xbmc.LOGINFO)
        client.subscribe(MQTT_TOPIC_SUB)
        
        # Muestra un mensaje rápido flotante en la esquina de Kodi
        xbmcgui.Dialog().notification("IPTV PROXY", "🟢 Conectado al servidor...", xbmcgui.NOTIFICATION_INFO, 3500)
         # --------------------------------------------------------
        # ¡AQUÍ ADQUIRIMOS LA MAC Y LA ENVIAMOS AL CONECTARSE!
        # --------------------------------------------------------
        mac_actual = obtener_mac_dispositivo()
        mqttMac=mac_actual
        xbmc.log("MQTT MAC: "+mqttMac, xbmc.LOGERROR)
        payload_online = {
            "status": "online",
            "message": "Kodi sincronizado",
            "mac_address": mac_actual  # Se adjunta de manera permanente en el reporte de conexión
        }
        # Reportar online al exterior
        try:
            client.publish(MQTT_TOPIC_PUB, json.dumps(payload_online, ensure_ascii=False))
        except:
            pass
    else:
        esta_conectado = False
        xbmc.log(f"MQTT Error: Falló la conexión inicial con código {codigo}", xbmc.LOGERROR)

def al_desconectar(client, userdata, rc):
    """Callback invocado automáticamente cuando se interrumpe la conexión de red"""
    global esta_conectado, _abortando_servicio
    esta_conectado = False
    
    xbmc.log(f"MQTT Alerta: Cliente desconectado del broker (Código de salida: {rc}).", xbmc.LOGWARNING)
    
    # Muestra un mensaje rápido en la pantalla de la TV advirtiendo la desconexión
    xbmcgui.Dialog().notification("IPTV PROXY", "🔴 Conexión perdida. Intentando reconectar...", xbmcgui.NOTIFICATION_WARNING, 3500)
    
    # Si Kodi se está cerrando por completo, salimos del hilo y no intentamos reconectar
    if _abortando_servicio:
        return

    # Creamos un hilo independiente para procesar los reintentos de reconexión sin congelar a Kodi
    threading.Thread(target=bucle_reconexion_infinita, args=(client,), daemon=True).start()

def bucle_reconexion_infinita(client):
    """Intenta reconectarse al broker de manera infinita cada 5 segundos si la red se cae"""
    global esta_conectado, _abortando_servicio
    
    xbmc.log("MQTT: Iniciando bucle de reconexión forzada en segundo plano.", xbmc.LOGINFO)
    
    while not esta_conectado and not _abortando_servicio:
        try:
            xbmc.log("IPTV PROXY: Intentando restablecer sockets con el broker...", xbmc.LOGINFO)
            # Reconnect es un método nativo de tu archivo mqtt_kodi.py
            client.reconnect() 
            # Si reconecta con éxito, el flujo saltará automáticamente al evento al_conectar de arriba
            break 
        except Exception as err:
            xbmc.log(f"Reconexión fallida: {err}. Siguiente intento en 5 segundos.", xbmc.LOGDEBUG)
            time.sleep(5)

def al_recibir_mensaje(client, userdata, msg):
    """Mapea y procesa los comandos garantizando compatibilidad total"""
    global _callback_externo
    try:
        payload = msg.payload.decode("utf-8", errors="ignore").strip()
        xbmc.log(f"MQTT Mensaje Recibido -> Payload: {payload}", xbmc.LOGINFO)
        
        payload_sanitizado = str(payload)
        
        try:
            datos = json.loads(payload_sanitizado)
            comando = datos.get("comando")
            parametro = datos.get("parametro", "")
        except (json.JSONDecodeError, ValueError):
            comando = payload_sanitizado
            parametro = ""

        if _callback_externo is not None:
            _callback_externo(comando, parametro)
            return

    except Exception as e:
        xbmc.log(f"MQTT Error crítico en recepción: {e}", xbmc.LOGERROR)

# ============================================================
# INICIALIZACIÓN Y PUBLICACIÓN REMOTA
# ============================================================
def iniciar_mqtt(monitor, callback_mensaje=None):
    """Inicializa el hilo en segundo plano para escuchar y procesar tramas"""
    global _instancia_cliente, _callback_externo, _abortando_servicio
    
    _callback_externo = callback_mensaje
    _abortando_servicio = False

    def bucle_mqtt():
        global _instancia_cliente, _abortando_servicio
        cliente = mqtt.Client()
        
        if MQTT_USER and MQTT_PASS:
            cliente.username_pw_set(MQTT_USER, MQTT_PASS)
            
        cliente.on_connect = al_conectar
        cliente.on_disconnect = al_desconectar
        cliente.on_message = al_recibir_mensaje

        try:
            cliente.connect(MQTT_BROKER, MQTT_PUERTO, keepalive=60)
            _instancia_cliente = cliente
            
            # Mantiene viva la escucha mientras Kodi no solicite el cierre del addon
            while not monitor.abortRequested():
                cliente.loop(timeout=1.0)
                
            # Si salimos del loop porque Kodi se apaga o el addon se deshabilita
            _abortando_servicio = True
            cliente.disconnect()
            _instancia_cliente = None
            xbmc.log("MQTT: Servicio finalizado limpiamente por el Monitor de Kodi.", xbmc.LOGINFO)
        except Exception as e:
            xbmc.log(f"MQTT Error crítico en bucle: {e}", xbmc.LOGERROR)

    threading.Thread(target=bucle_mqtt, daemon=True).start()

def publicar_mensaje(payload, topic=MQTT_TOPIC_PUB, qos=0, retain=False):
    """Envía información desde Kodi hacia el exterior de forma segura"""
    global _instancia_cliente, esta_conectado
    
    intentos = 0
    while not esta_conectado and intentos < 30:
        time.sleep(0.1)
        intentos += 1
        
    if _instancia_cliente is None or not esta_conectado:
        xbmc.log("MQTT Publicar Cancelado: El cliente no se encuentra conectado.", xbmc.LOGWARNING)
        return False
        
    try:
        if isinstance(payload, (dict, list)):
            payload = json.dumps(payload, ensure_ascii=False)
            
        _instancia_cliente.publish(topic, payload, qos, retain)
        return True
    except Exception as e:
        xbmc.log(f"MQTT Error al publicar mensaje: {e}", xbmc.LOGERROR)
        return False
