import os
import xbmc

def guardar_archivo_dinamico(ruta_base_addon, ruta_relativa, contenido_codigo):
    """
    Recibe una ruta relativa (incluyendo cualquier nivel de subdirectorios)
    y escribe/sobreescribe el archivo de manera limpia, creando las carpetas
    intermedias si no existen.
    """
    xbmc.log("guardar_archivo_dinamico", xbmc.LOGWARNING)
    if not ruta_relativa:
        xbmc.log("Gestor Archivos Error: La ruta del archivo está vacía.", xbmc.LOGWARNING)
        return False

    try:
        # Normalizar la ruta para evitar problemas entre Windows y Linux/Android (\ vs /)
        ruta_relativa_normalizada = os.path.normpath(ruta_relativa)
        
        # Unir la ruta base del addon con la ruta relativa del archivo recibido
        ruta_final = os.path.join(ruta_base_addon, ruta_relativa_normalizada)
        
        # Obtener el directorio contenedor del archivo (ej: recursos/lib/subcarpeta)
        carpeta_destino = os.path.dirname(ruta_final)

        # Crear el directorio y TODOS sus subdirectorios si no existen automáticamente
        if not os.path.exists(carpeta_destino):
            os.makedirs(carpeta_destino)
            xbmc.log(f"Gestor Archivos: Creados subdirectorios nuevos -> {carpeta_destino}", xbmc.LOGINFO)

        # Escribir o sobreescribir el archivo en formato de texto UTF-8
        with open(ruta_final, 'w', encoding='utf-8') as f:
            f.write(contenido_codigo)
            
        xbmc.log(f"Gestor Archivos Éxito: Archivo actualizado en -> {ruta_final}", xbmc.LOGINFO)
        return True
        
    except Exception as e:
        xbmc.log(f"Gestor Archivos Error crítico al escribir en subdirectorios: {e}", xbmc.LOGERROR)
        return False
