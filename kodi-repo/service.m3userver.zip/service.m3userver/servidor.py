import os
import http.server
import socketserver
import importlib

from urllib.parse import urlparse, parse_qs, unquote

from scrapers.playback import extraer_playback
from scrapers.merge_lists import unir_listas_m3u


# ============================================================
# XBMC / KODI
# ============================================================

try:

    import xbmc

except ImportError:

    class XBMC:

        LOGINFO = "INFO"
        LOGERROR = "ERROR"
        LOGWARNING = "WARNING"

        @staticmethod
        def log(
            mensaje,
            nivel=None
        ):

            print(
                f"[{nivel}] {mensaje}"
            )

        @staticmethod
        def executebuiltin(
            comando
        ):

            print(
                f"[KODI] {comando}"
            )

        @staticmethod
        def getInfoLabel(
            valor
        ):

            if valor == "Network.IPAddress":

                return "127.0.0.1"

            return ""


    xbmc = XBMC()


# ============================================================
# CONFIGURACIÓN
# ============================================================

PORT = 8090


# ============================================================
# HANDLER
# ============================================================

class Handler(
    http.server.SimpleHTTPRequestHandler
):


    def __init__(
        self,
        *args,
        directory=None,
        **kwargs
    ):

        super().__init__(
            *args,
            directory=directory,
            **kwargs
        )


    # ========================================================
    # LOG
    # ========================================================

    def log_message(
        self,
        format,
        *args
    ):

        xbmc.log(
            format % args,
            xbmc.LOGINFO
        )


    # ========================================================
    # OBTENER STREAM SEGÚN SCRAPER
    # ========================================================

    def obtener_stream(
        self,
        url,
        referer,
        scraper
    ):

        # ----------------------------------------------------
        # SIN SCRAPER
        # ----------------------------------------------------

        if not scraper:

            xbmc.log(
                "Sin scraper. "
                "Usando scraper por defecto",
                xbmc.LOGINFO
            )

            try:

                return extraer_playback(
                    url,
                    referer
                )
                print("hola")
            except Exception as e:

                xbmc.log(
                    "Error scraper por defecto: "
                    + str(e),
                    xbmc.LOGERROR
                )

                return None


        # ----------------------------------------------------
        # LIMPIAR SCRAPER
        # ----------------------------------------------------

        scraper = scraper.strip().lower()


        # ----------------------------------------------------
        # SEGURIDAD
        # ----------------------------------------------------

        if not scraper:

            return None


        if not scraper.replace(
            "_",
            ""
        ).isalnum():

            xbmc.log(
                "Nombre de scraper no válido: "
                + scraper,
                xbmc.LOGERROR
            )

            return None


        # ----------------------------------------------------
        # NOMBRE DEL MÓDULO
        # ----------------------------------------------------

        nombre_modulo = (
            "scrapers.scraper_"
            + scraper
        )


        xbmc.log(
            "Cargando scraper: "
            + nombre_modulo,
            xbmc.LOGINFO
        )


        # ====================================================
        # IMPORTAR SCRAPER DINÁMICAMENTE
        # ====================================================

        try:

            modulo = importlib.import_module(
                nombre_modulo
            )

        except ImportError as e:

            xbmc.log(
                "No se pudo importar "
                + nombre_modulo
                + ": "
                + str(e),
                xbmc.LOGERROR
            )

            return None

        except Exception as e:

            xbmc.log(
                "Error cargando "
                + nombre_modulo
                + ": "
                + str(e),
                xbmc.LOGERROR
            )

            return None


        # ====================================================
        # BUSCAR extraer_playback
        # ====================================================

        funcion = getattr(
            modulo,
            "extraer_playback",
            None
        )


        if not callable(
            funcion
        ):

            xbmc.log(
                nombre_modulo
                + " no tiene "
                + "extraer_playback()",
                xbmc.LOGERROR
            )

            return None


        # ====================================================
        # EJECUTAR SCRAPER
        # ====================================================

        try:

            xbmc.log(
                "Ejecutando scraper: "
                + scraper,
                xbmc.LOGINFO
            )


            # ------------------------------------------------
            # STREAMX
            # ------------------------------------------------

            if scraper == "streamx":

                stream = funcion(
                    url
                )


            # ------------------------------------------------
            # OTROS SCRAPERS
            # ------------------------------------------------

            else:

                try:

                    stream = funcion(
                        url,
                        referer
                    )

                except TypeError:

                    stream = funcion(
                        url
                    )


            return stream


        except Exception as e:

            xbmc.log(
                "Error ejecutando scraper "
                + scraper
                + ": "
                + str(e),
                xbmc.LOGERROR
            )

            return None


    # ========================================================
    # GET
    # ========================================================

    def do_GET(
        self
    ):

        ruta = urlparse(
            self.path
        )


        # ====================================================
        # PROXY
        # ====================================================

        if ruta.path == "/proxy":


            parametros = parse_qs(
                ruta.query
            )


            # ------------------------------------------------
            # URL
            # ------------------------------------------------

            url = parametros.get(
                "url",
                [None]
            )[0]


            if url:

                url = unquote(
                    url
                )


            # ------------------------------------------------
            # REFERER
            # ------------------------------------------------

            referer = parametros.get(
                "referer",
                [None]
            )[0]


            if referer:

                referer = unquote(
                    referer
                )
                print ("ref:",referer)


            # ------------------------------------------------
            # SCRAPER
            # ------------------------------------------------

            scraper = parametros.get(
                "scraper",
                [None]
            )[0]


            if scraper:

                scraper = unquote(
                    scraper
                )


            # =================================================
            # VALIDAR URL
            # =================================================

            if url:


                xbmc.log(
                    "Extrayendo stream: "
                    + url,
                    xbmc.LOGINFO
                )


                if scraper:

                    xbmc.log(
                        "Scraper solicitado: "
                        + scraper,
                        xbmc.LOGINFO
                    )

                else:

                    xbmc.log(
                        "No se especificó scraper",
                        xbmc.LOGINFO
                    )


                # =============================================
                # OBTENER STREAM
                # =============================================

                stream = self.obtener_stream(
                    url,
                    referer,
                    scraper
                )


                # =============================================
                # STREAM ENCONTRADO
                # =============================================

                if stream:


                    xbmc.log(
                        "Stream encontrado: "
                        + str(stream),
                        xbmc.LOGINFO
                    )


                    self.send_response(
                        302
                    )


                    self.send_header(
                        "Location",
                        stream
                    )


                    self.end_headers()

                    return


                # =============================================
                # STREAM NO ENCONTRADO
                # =============================================

                self.send_response(
                    404
                )


                self.send_header(
                    "Content-Type",
                    "text/plain; charset=utf-8"
                )


                self.end_headers()


                self.wfile.write(
                    "No se encontro stream".encode(
                        "utf-8"
                    )
                )

                return


        # ====================================================
        # SERVIDOR NORMAL
        # ====================================================

        super().do_GET()


# ============================================================
# INICIAR SERVIDOR
# ============================================================

def iniciar_servidor(
    carpeta
):

    socketserver.TCPServer.allow_reuse_address = True


    with socketserver.TCPServer(
        (
            "",
            PORT
        ),
        lambda *args, **kwargs:
            Handler(
                *args,
                directory=carpeta,
                **kwargs
            )

    ) as servidor:


        xbmc.log(
            "Servidor HTTP activo "
            "puerto "
            + str(PORT),
            xbmc.LOGINFO
        )


        servidor.serve_forever()


# ============================================================
# EJECUCIÓN DIRECTA
# ============================================================

if __name__ == "__main__":

    carpeta = os.path.dirname(
        os.path.abspath(__file__)
    )

    print(
        "[*] Ejecución directa detectada"
    )

    print(
        "[*] Carpeta: "
        + carpeta
    )

    iniciar_servidor(
        carpeta
    )
